<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Mixteca Exterior - Contacto</title>
	<?php include 'inc/head_common.php'; ?>
</head>
<body>
	<?php include 'inc/header.php'; ?>

	<?php include 'inc/footer.php'; ?>
	<?php include 'inc/footer_common.php'; ?>
</body>
</html>