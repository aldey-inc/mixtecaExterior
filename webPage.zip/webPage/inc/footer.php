<footer>
	<div class="container">
		<div class="row">
			<div class="col-xs-4">@mixtecaexterior</div>
			<div class="col-xs-4">@mixtecaexterior</div>
			<div class="col-xs-4">@mixtecaexterior</div>
			<div class="clearfix"></div>
			<div class="col-xs-4">
				<h3>AGRADECIMIENTOS</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias, eum animi ipsum voluptatem natus fugit tempora veniam recusandae blanditiis, consectetur a quod ut eius architecto, non at ducimus, ratione amet.</p>
			</div>
			<div class="col-xs-4">
				<h3>PROXIMOS EVENTOS</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem placeat quisquam, tenetur consectetur nihil incidunt aut voluptatibus veniam labore nostrum repudiandae quo ut veritatis, perspiciatis voluptatum provident quaerat expedita dolor!</p>
			</div>
			<div class="col-xs-4">
				<h3>NO TE PIERDAS NUESTRAS NOTICIAS </h3>
				<form id="subscribe-form" action="">
					<div class="row">
						<div class="col-lg-8 col-xs-12">
							<label class="sr-only" for="email">Tu correo electrónico aquí</label>
							<input type="text" id="email" name="email" class="form-control input-lg" placeholder="Tu correo electrónico">
						</div>
						<div class="col-lg-4 col-xs-6">
							<button class="btn btn-custom btn-lg">Suscribirme</button>
						</div>
					</div>
				</form>						
			</div>
		</div>
	</div>
</footer>